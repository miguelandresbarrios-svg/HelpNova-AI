@echo off
if not exist .env (
  echo Copia .env.example como .env y configura DB_PASSWORD.
  pause
  exit /b 1
)
if not exist node_modules (
  call npm install
)
call npm start
pause
