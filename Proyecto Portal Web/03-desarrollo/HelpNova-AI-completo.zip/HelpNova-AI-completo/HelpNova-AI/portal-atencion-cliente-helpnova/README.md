# HelpNova AI

Portal web de atención al cliente con MySQL y panel administrativo.

## Instalación rápida
1. Ejecuta `database/database.sql` en MySQL Workbench.
2. Copia `.env.example` como `.env`.
3. Ajusta `DB_PASSWORD`.
4. Ejecuta `npm install`.
5. Ejecuta `npm start`.
6. Abre `http://localhost:3000`.

Rutas:
- `/`
- `/nueva-solicitud`
- `/admin`

La lógica de IA está simulada en `services/iaService.js` y puede sustituirse por una API real.
