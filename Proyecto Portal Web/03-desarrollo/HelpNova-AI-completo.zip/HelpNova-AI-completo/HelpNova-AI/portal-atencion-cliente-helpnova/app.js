const path = require('path');

require('dotenv').config({
  path: path.join(__dirname, '.env')
});

const express = require('express');
const cors = require('cors');
const db = require('./config/database');
const solicitudesRoutes = require('./routes/solicitudes');
const reportesRoutes = require('./routes/reportes');

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get('/nueva-solicitud', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'nueva-solicitud.html'));
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'admin.html'));
});

app.use('/api/solicitudes', solicitudesRoutes);
app.use('/api/reportes', reportesRoutes);

async function validarConexion() {
  try {
    const connection = await db.getConnection();
    await connection.ping();
    connection.release();
    console.log('✅ Conexión a MySQL correcta');
  } catch (error) {
    console.error('❌ Error de conexión a MySQL:', error.message);
  }
}

app.listen(PORT, async () => {
  console.log(`🚀 HelpNova AI ejecutándose en http://localhost:${PORT}`);
  await validarConexion();
});
