CREATE DATABASE IF NOT EXISTS helpnova_ai
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE helpnova_ai;

DROP TABLE IF EXISTS solicitudes;

CREATE TABLE solicitudes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  asunto VARCHAR(150) NOT NULL,
  descripcion TEXT NOT NULL,
  categoria VARCHAR(100),
  prioridad VARCHAR(30),
  respuesta TEXT,
  escalamiento BOOLEAN NOT NULL DEFAULT FALSE,
  estado VARCHAR(30) NOT NULL DEFAULT 'Nuevo',
  fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fecha_actualizacion DATETIME NULL
);
