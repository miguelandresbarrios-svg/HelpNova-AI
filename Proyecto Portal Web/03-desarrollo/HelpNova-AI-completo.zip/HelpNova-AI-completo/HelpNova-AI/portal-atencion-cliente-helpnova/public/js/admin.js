async function cargarSolicitudes() {
  const tbody = document.getElementById('tablaSolicitudes');
  try {
    const response = await fetch('/api/solicitudes');
    const solicitudes = await response.json();
    tbody.innerHTML = solicitudes.map(s => `
      <tr>
        <td>${s.id}</td>
        <td>${s.asunto}</td>
        <td>${s.categoria || ''}</td>
        <td>${s.prioridad || ''}</td>
        <td>${s.estado || ''}</td>
        <td>${new Date(s.fecha_creacion).toLocaleString()}</td>
        <td>
          <select onchange="actualizarEstado(${s.id}, this.value)">
            ${['Nuevo','Respondido por IA','Escalado','En proceso','Cerrado']
              .map(e => `<option value="${e}" ${e === s.estado ? 'selected' : ''}>${e}</option>`)
              .join('')}
          </select>
        </td>
      </tr>`).join('');
  } catch (error) {
    tbody.innerHTML = '<tr><td colspan="7">Error cargando solicitudes.</td></tr>';
  }
}

async function actualizarEstado(id, estado) {
  await fetch(`/api/solicitudes/${id}/estado`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ estado })
  });
  await cargarSolicitudes();
  await cargarReporte();
}

async function cargarReporte() {
  try {
    const response = await fetch('/api/reportes/mensual');
    const data = await response.json();
    document.getElementById('totalMes').textContent = data.resumen?.total || 0;
    document.getElementById('respondidasIA').textContent = data.resumen?.respondidas_ia || 0;
    document.getElementById('escaladas').textContent = data.resumen?.escaladas || 0;
    document.getElementById('cerradas').textContent = data.resumen?.cerradas || 0;
    document.getElementById('categorias').innerHTML = (data.categorias || [])
      .map(c => `<li>${c.categoria}: ${c.cantidad}</li>`).join('');
  } catch (error) {
    console.error(error);
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  await cargarSolicitudes();
  await cargarReporte();
});
