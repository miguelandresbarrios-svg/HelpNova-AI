document.addEventListener('DOMContentLoaded', () => {
  const formulario = document.getElementById('formSolicitud');
  const resultado = document.getElementById('resultado');
  if (!formulario || !resultado) return;

  formulario.addEventListener('submit', async (event) => {
    event.preventDefault();
    const asunto = document.getElementById('asunto').value.trim();
    const descripcion = document.getElementById('descripcion').value.trim();

    resultado.innerHTML = '<div class="tarjeta"><p>HelpNova AI está analizando tu solicitud...</p></div>';

    try {
      const response = await fetch('/api/solicitudes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ asunto, descripcion })
      });

      const datos = await response.json();
      if (!response.ok) throw new Error(datos.mensaje || 'No fue posible procesar la solicitud.');

      resultado.innerHTML = `
        <div class="tarjeta">
          <h3>Respuesta de HelpNova AI</h3>
          <p><strong>Número de solicitud:</strong> ${datos.id}</p>
          <p><span class="badge">${datos.categoria}</span><span class="badge">Prioridad: ${datos.prioridad}</span></p>
          <p><strong>Estado:</strong> <span class="${datos.escalamiento ? 'estado-escalado' : 'estado-ok'}">${datos.estado}</span></p>
          <p><strong>Posible solución:</strong></p>
          <p>${datos.respuesta}</p>
        </div>`;
      formulario.reset();
    } catch (error) {
      resultado.innerHTML = `<div class="tarjeta"><h3>Error</h3><p>${error.message}</p></div>`;
    }
  });
});
