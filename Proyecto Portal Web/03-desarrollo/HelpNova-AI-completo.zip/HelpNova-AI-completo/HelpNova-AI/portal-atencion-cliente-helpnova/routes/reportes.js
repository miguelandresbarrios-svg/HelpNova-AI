const express = require('express');
const db = require('../config/database');

const router = express.Router();

router.get('/mensual', async (req, res) => {
  try {
    const [resumenRows] = await db.execute(`
      SELECT
        COUNT(*) AS total,
        SUM(estado = 'Respondido por IA') AS respondidas_ia,
        SUM(estado = 'Escalado') AS escaladas,
        SUM(estado = 'En proceso') AS en_proceso,
        SUM(estado = 'Cerrado') AS cerradas
      FROM solicitudes
      WHERE YEAR(fecha_creacion) = YEAR(CURDATE())
        AND MONTH(fecha_creacion) = MONTH(CURDATE())
    `);

    const [categorias] = await db.execute(`
      SELECT categoria, COUNT(*) AS cantidad
      FROM solicitudes
      WHERE YEAR(fecha_creacion) = YEAR(CURDATE())
        AND MONTH(fecha_creacion) = MONTH(CURDATE())
      GROUP BY categoria
      ORDER BY cantidad DESC
    `);

    res.json({ resumen: resumenRows[0], categorias });
  } catch (error) {
    console.error('Error GET /api/reportes/mensual:', error);
    res.status(500).json({ mensaje: 'No fue posible generar el reporte mensual.' });
  }
});

module.exports = router;
