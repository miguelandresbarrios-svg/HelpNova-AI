const express = require('express');
const db = require('../config/database');
const { analizarSolicitud } = require('../services/iaService');

const router = express.Router();

router.post('/', async (req, res) => {
  try {
    const { asunto, descripcion } = req.body;

    if (!asunto || !descripcion) {
      return res.status(400).json({
        mensaje: 'El asunto y la descripción son obligatorios.'
      });
    }

    const analisis = analizarSolicitud(descripcion);
    const estado = analisis.escalamiento ? 'Escalado' : 'Respondido por IA';

    const [resultado] = await db.execute(
      `INSERT INTO solicitudes
      (asunto, descripcion, categoria, prioridad, respuesta, escalamiento, estado)
      VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        asunto,
        descripcion,
        analisis.categoria,
        analisis.prioridad,
        analisis.respuesta,
        analisis.escalamiento,
        estado
      ]
    );

    res.status(201).json({
      id: resultado.insertId,
      asunto,
      descripcion,
      categoria: analisis.categoria,
      prioridad: analisis.prioridad,
      respuesta: analisis.respuesta,
      escalamiento: analisis.escalamiento,
      estado
    });
  } catch (error) {
    console.error('Error POST /api/solicitudes:', error);
    res.status(500).json({
      mensaje: 'No fue posible registrar la solicitud.',
      detalle: error.message
    });
  }
});

router.get('/', async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT id, asunto, descripcion, categoria, prioridad, respuesta,
              escalamiento, estado, fecha_creacion
       FROM solicitudes
       ORDER BY fecha_creacion DESC`
    );
    res.json(rows);
  } catch (error) {
    console.error('Error GET /api/solicitudes:', error);
    res.status(500).json({ mensaje: 'No fue posible consultar las solicitudes.' });
  }
});

router.patch('/:id/estado', async (req, res) => {
  try {
    const { id } = req.params;
    const { estado } = req.body;
    const permitidos = ['Nuevo', 'Respondido por IA', 'Escalado', 'En proceso', 'Cerrado'];

    if (!permitidos.includes(estado)) {
      return res.status(400).json({ mensaje: 'Estado no permitido.' });
    }

    const [resultado] = await db.execute(
      `UPDATE solicitudes
       SET estado = ?, fecha_actualizacion = NOW()
       WHERE id = ?`,
      [estado, id]
    );

    if (resultado.affectedRows === 0) {
      return res.status(404).json({ mensaje: 'Solicitud no encontrada.' });
    }

    res.json({ mensaje: 'Estado actualizado correctamente.' });
  } catch (error) {
    console.error('Error PATCH /api/solicitudes/:id/estado:', error);
    res.status(500).json({ mensaje: 'No fue posible actualizar el estado.' });
  }
});

module.exports = router;
