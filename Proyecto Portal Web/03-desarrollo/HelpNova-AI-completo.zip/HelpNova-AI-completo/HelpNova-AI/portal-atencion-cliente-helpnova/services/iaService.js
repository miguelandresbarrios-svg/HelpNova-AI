function analizarSolicitud(descripcion = '') {
  const texto = descripcion.toLowerCase();

  if (
    texto.includes('contraseña') ||
    texto.includes('ingresar') ||
    texto.includes('acceso') ||
    texto.includes('usuario')
  ) {
    return {
      categoria: 'Acceso al sistema',
      prioridad: 'Media',
      respuesta:
        'Verifica que el correo o usuario ingresado sea correcto. Si olvidaste tu contraseña, utiliza la opción de recuperación. Si el problema continúa, un asesor puede revisar tu caso.',
      escalamiento: false
    };
  }

  if (
    texto.includes('factura') ||
    texto.includes('pago') ||
    texto.includes('cobro') ||
    texto.includes('saldo')
  ) {
    return {
      categoria: 'Facturación',
      prioridad: 'Media',
      respuesta:
        'Revisa el número de factura, el valor cobrado y el comprobante de pago. Si detectas una diferencia, la solicitud será escalada para validación por un asesor.',
      escalamiento: true
    };
  }

  if (
    texto.includes('pedido') ||
    texto.includes('entrega') ||
    texto.includes('envío') ||
    texto.includes('envio') ||
    texto.includes('demora')
  ) {
    return {
      categoria: 'Entregas',
      prioridad: 'Alta',
      respuesta:
        'Verifica el número del pedido y la fecha estimada de entrega. Si la fecha ya venció o el pedido aparece entregado sin haberlo recibido, el caso será escalado para revisión.',
      escalamiento: true
    };
  }

  return {
    categoria: 'General',
    prioridad: 'Baja',
    respuesta:
      'Tu solicitud fue recibida. Para ofrecer una solución más precisa, incluye fechas, números de referencia o mensajes de error relacionados con el caso.',
    escalamiento: false
  };
}

module.exports = { analizarSolicitud };
